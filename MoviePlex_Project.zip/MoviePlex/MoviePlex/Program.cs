﻿using System;

namespace MoviePlex
{
    class Program
    {
        public static int playingMoviesCount = 0;              // integer to store number of movies playing
        public static string[,] moviesArr = new string[10, 2]; // 2D array to store playing movies and age limit
        static void Main(string[] args)
        {
            CenterText("************************************");
            CenterText("*** Welcome to MoviePlex Theatre ***");
            CenterText("************************************");
            Console.WriteLine("\n");
            ChoiceSelection();
            Console.ReadKey();
        }

        private static void CenterText(String text)
        {
            Console.Write(new string(' ', (Console.WindowWidth - text.Length) / 2));
            Console.WriteLine(text);
        }

        private static void ChoiceSelection()    // User selects from the given options
        {
            string selectedChoice;
            bool flag;
            do  
            {
                flag = false;
                Console.WriteLine("\nPlease Select From The Following Options:");
                Console.WriteLine("1: Administrator");
                Console.WriteLine("2: Guests");
                Console.Write("\nSelection: ");

                selectedChoice = Console.ReadLine();
                if(selectedChoice == "1")
                {
                    AdministratorOption();
                    flag = true;
                }
                else if (selectedChoice == "2")
                { 
                    GuestOption(playingMoviesCount);
                    flag = true;      
                }
                else
                {
                    Console.WriteLine("Invalid Choice, Please Enter Valid Selection");
                    ChoiceSelection();
                }
            } while (flag != true);
        }

        private static void AdministratorOption()  // Administrator option is selected
        {
            string password;
            int numberOfAttempts = 5; // max attempts before succesful login 

            do                                     // Check for Admin's password 
            {
                password = string.Empty;
                Console.Write("\nPlease Enter The Admin Password or press B to go back : ");
                ConsoleKey key;
                do
                {
                    var info = Console.ReadKey(intercept: true);    // masking of password
                    key = info.Key;
                    if (key == ConsoleKey.Backspace && password.Length > 0)
                    {
                        password = password.Substring(0, (password.Length - 1));
                        Console.Write("\b \b");
                    }
                    else if (!char.IsControl(info.KeyChar))
                    {
                        password += info.KeyChar;
                        Console.Write("*");
                       
                    }

                } while (key != ConsoleKey.Enter);

                if (password != "12345")
                {
                    if (password == "B")
                    {
                        ChoiceSelection();
                    }
                    else
                    {
                        if (numberOfAttempts <= 1)
                        {
                            Console.WriteLine("\nYou entered an Invalid password.");
                            Console.WriteLine("\nYou have no more attempt(s) to enter the password, Please try again after sometime");
                            ChoiceSelection();
                        }
                        else
                        {
                            Console.WriteLine("\nYou entered an Invalid password.");
                            numberOfAttempts--;
                            Console.WriteLine("\nYou have " + numberOfAttempts + " more attempts to enter the correct password OR Press B to go back to the previous screen");
                        }
                    }
                }
            } while (password != "12345"); 

            InputMoviesList(); // to insert movies into the system
        }

        private static void InputMoviesList()             // Admin can enter the movies list
        {
            Console.WriteLine();
            Console.WriteLine("\nWelcome MoviePlex Administrator");
            Console.Write("\nHow many movies are now playing today?: ");
            string playingMoviesInput = Console.ReadLine();
            int maxNoOfmovies = 10;

            if (!int.TryParse(playingMoviesInput, out int moviesCount) || moviesCount < 1 || moviesCount > maxNoOfmovies)
            {
                Console.WriteLine("\nInvalid Input, Please Enter Number from 1 to 10\n");
                InputMoviesList();
            }
            else
            {
                playingMoviesCount = moviesCount;

                string word;
                string[] wordOrdinalArr = new string[] {"First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eight", "Ninth", "Tenth"};
                for (int i = 0; i < playingMoviesCount; i++)
                {
                    word = wordOrdinalArr[i];
                    
                    for (int j = 0; j < 2; j++)
                    {
                        if (j == 0)
                        {
                            Console.Write("\nPlease Enter The " + word + " Movie's Name: ");
                            moviesArr[i, j] = Console.ReadLine();
                        }
                        else
                        {
                            Console.Write("Please Enter The Age Limit or Rating For The " + word + " Movie: ");
                            string ageLimit = Console.ReadLine();

                            if (ageLimit == "G" || ageLimit == "PG" || ageLimit == "PG-13" || ageLimit == "R" || ageLimit == "NC-17") 
                            {
                                moviesArr[i, j] = ageLimit;
                            }
                            else if (int.TryParse(ageLimit, out int ageNumber) && ageNumber > 1)
                            {
                                moviesArr[i, j] = ageNumber.ToString();
                            }
                            else
                            {
                                Console.WriteLine("\nInvalid Input, Please Enter Again.");
                                Console.WriteLine("\nFor Example.");
                                Console.WriteLine("G – General Audience, any age is good");
                                Console.WriteLine("PG – We will take PG as 10 years or older");
                                Console.WriteLine("PG - 13 – We will take PG - 13 as 13 years or older");
                                Console.WriteLine("R – We will take R as 15 years or older.Don’t worry about accompany by parent case.");
                                Console.WriteLine("NC - 17 – We will take NC - 17 as 17 years or older\n");
                                InputMoviesList();
                            }
                        }
                        Console.WriteLine();
                    }
                }

                DisplayPlayingMovies(playingMoviesCount);        // function to display movies playing and age restriction

                bool flag;
                do
                {
                    flag = false;

                    string choice;
                    Console.Write("\n\nYour Movies Playing Today Are Listed Above. Are you satisfied? (Y/N)? ");
                    choice = Console.ReadLine();

                    if (choice == "Y" || choice== "y")
                    {
                        ChoiceSelection();
                        flag = true;
                    }
                    else if (choice == "N" || choice =="n")
                    {
                        InputMoviesList();
                        flag = true;
                    }
                    else
                    {
                        Console.WriteLine("\nInvalid Input, Please Enter (Y/N)");
                    }
                } while (flag != true);
            }
        }

        private static void GuestOption(int playingMoviesCount) // Guest option is selected
        {
            string ageLimitString;
            int selectedMovieNumber, userAge, ageLimit;
            bool flag;
            Console.WriteLine("\n");
            if (playingMoviesCount == 0) 
            {
                Console.WriteLine("\nThere are no movies playing today\n");
                ChoiceSelection();
            }
            else
            {
                Console.WriteLine("There are " + playingMoviesCount + " movies playing today. Please choose from the following movies:");

                DisplayPlayingMovies(playingMoviesCount);               // function to display movies playing and age restriction

                do 
                {
                    Console.WriteLine("\n");
                    Console.Write("Which Movie Would You Like To Watch: ");
                    string enteredMovieNumber = Console.ReadLine();
                    bool val = int.TryParse(enteredMovieNumber, out int movieNumber);

                    if (!val || movieNumber < 1 || movieNumber > playingMoviesCount)
                    {
                        Console.WriteLine("\nInvalid Input, Please Enter Movie Number from above List\n");
                        flag = false;
                    }
                    else
                    {
                        selectedMovieNumber = movieNumber;
                        do 
                        {
                            Console.Write("Please Enter Your Age For Verification: ");
                            string enteredAge = Console.ReadLine();
                            bool value = int.TryParse(enteredAge, out int ageNumber);

                            if (!value || ageNumber < 1)
                            {
                                Console.WriteLine("\nInvalid Input, Please enter age in number and should be greater than 0\n");
                                flag = false;
                            }
                            else
                            {
                                userAge = ageNumber; 
                                ageLimitString = moviesArr[selectedMovieNumber - 1, 1]; 
                                switch (ageLimitString) 
                                {
                                    case "G":
                                        ageLimit = 0;
                                        break;
                                    case "PG":
                                        ageLimit = 10;
                                        break;
                                    case "PG-13":
                                        ageLimit = 13;
                                        break;
                                    case "R":
                                        ageLimit = 15;
                                        break;
                                    case "NC-17":
                                        ageLimit = 17;
                                        break;
                                    default:
                                        ageLimit = Convert.ToInt32(moviesArr[selectedMovieNumber - 1, 1]);
                                        break;
                                }

                                if (userAge >= ageLimit) 
                                {
                                    Console.WriteLine("\nEnjoy The Movie!\n");

                                    string selectedChoice;
                                    do 
                                    {
                                        Console.WriteLine("Press M to go back to the Guest Main Menu.");
                                        Console.WriteLine("Press S to go back to the Start Page");
                                        selectedChoice = Console.ReadLine();

                                        if (selectedChoice == "M")
                                        {
                                            GuestOption(playingMoviesCount);
                                        }
                                        else if (selectedChoice == "S")
                                        {
                                            ChoiceSelection();
                                        }
                                        else
                                        {
                                            Console.WriteLine("Invalid Input, Please enter choice (M/S)");
                                        }
                                    } while (!(selectedChoice == "M" || selectedChoice == "S"));
                                }
                                else
                                {
                                    Console.WriteLine("\nAge Limit for the selected movie is " + ageLimit + " Please select another movie from the list");
                                    GuestOption(playingMoviesCount);
                                }
                                flag = true;
                            }
                        } while (flag != true);
                    }
                } while (flag != true);
            }
        }

        private static void DisplayPlayingMovies(int playingMoviesCount)     //display movie and age restriction entered
        {
            for (int i = 0; i < playingMoviesCount; i++)  
            {
                Console.WriteLine("");
                for (int j = 0; j < 2; j++)
                {
                    if (j == 0)
                    {
                        Console.Write(i + 1 + ". " + moviesArr[i, j] + " {");
                    }
                    else
                    {
                        Console.Write(moviesArr[i, j] + "}");
                    }
                }
            }
        }
    }
}
